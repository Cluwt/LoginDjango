from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
import settings
from .models import Usuario
import subprocess
import sqlite3
import os

# Create your views here.

def LoginDjango(request):
    return render(request, 'home.html')

def login_sucesso(request):
    return render(request, 'Login_Sucesso.html')

def registro_sucesso(request):
    return render(request, 'Cadastro_Sucesso.html')

def mostrarAlerta():
    script_js = '''
<script>alert("Cadastrado ou Logado!");</script>
'''

def cadastrar_usuario(request):
    if request.method == 'POST':
        senha = request.POST.get('senha')
        email = request.POST.get('email')
        novo_usuario = Usuario(senha=senha, email=email)
        novo_usuario.save()
        messages.success(request, 'Usuário cadastrado com sucesso!')
        mostrarAlerta()
        return redirect('registro_sucesso') 
    else:
        return render(request, 'home.html')
    
def fazer_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('senha')

        DATABASE_PATH = os.path.join(settings.BASE_DIR, 'db.sqlite3')

        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM LoginDjango_usuario WHERE email=? AND senha=?", (email, senha))
        usuario = cursor.fetchone()

        conn.close()

        if usuario is not None:
            return redirect('login_sucesso')
        else:
            messages.error(request, 'Credenciais inválidas. Por favor, tente novamente.')
            
    return render(request, 'home.html')