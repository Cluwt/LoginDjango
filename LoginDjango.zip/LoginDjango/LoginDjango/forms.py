from django import forms
from LoginDjango.models import Usuario

class FormUsuario(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ("email", "senha")